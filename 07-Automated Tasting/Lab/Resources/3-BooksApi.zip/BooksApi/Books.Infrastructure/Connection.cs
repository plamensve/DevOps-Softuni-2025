﻿namespace Books.Infrastructure
{
    public class Connection
    {
        public const string ConnectionString = @"Server=.;Database=Books;Integrated Security=True;Encrypt=False";
    }
}
