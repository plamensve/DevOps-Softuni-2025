﻿using Books.Infrastructure.Data.Common;

namespace Books.Infrastructure.Data.Repositories
{
    public interface IBooksRepository : IRepository
    {
    }
}
